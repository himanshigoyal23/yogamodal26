# Analysis code for "Multimodal ML for digital yoga interventions" (synthetic benchmark)

    python generate_dataset.py                       # builds the 4 data files (seed 7)
    python analysis/analysis.py . analysis/results   # nested subject-grouped CV, all tables
    python analysis/make_figures.py analysis/results # Fig. 1, 2a, 2b

Everything is split by subject_id; hyper-parameters are tuned only inside each outer training fold.
Requires numpy, pandas, scikit-learn (>=1.6), matplotlib. Full run ~11 min on 2 cores (use --skip-repeats for ~2 min).

    python analysis/leakage_check.py . analysis/results   # random vs subject-grouped splits (Task 2, Task 3)
