"""Regenerates Fig. 1, Fig. 2a and Fig. 2b from results/results.json (output of analysis.py)."""
import json, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = Path(sys.argv[1])
R = json.load(open(OUT / "results.json"))
plt.rcParams.update({"font.size": 10, "axes.titleweight": "bold"})

# ---------------- Fig. 1: (a) out-of-fold predicted vs actual, (b) permutation importance
y = np.array(R["task1_y"]); p = np.array(R["task1"]["hgb"]["oof"])
r2 = R["task1"]["hgb"]["r2_pooled"]
fig, ax = plt.subplots(1, 2, figsize=(11, 4.3), gridspec_kw={"width_ratios": [1, 1.15]})
ax[0].scatter(y, p, s=22, alpha=.8, edgecolor="k", linewidth=.4, color="#1f77b4",
              label="Subjects ($N=200$)")
lo, hi = min(y.min(), p.min()) - 1, max(y.max(), p.max()) + 1
ax[0].plot([lo, hi], [lo, hi], "--", color="#444", label="Ideal fit ($y=x$)")
ax[0].set_xlim(lo, hi); ax[0].set_ylim(lo, hi); ax[0].set_aspect("equal")
ax[0].set_xlabel("Actual 12-week stress reduction ($\\Delta$PSS)")
ax[0].set_ylabel("Out-of-fold predicted ($\\Delta$PSS)")
ax[0].set_title(f"(a) Week-4 forecast, nested CV ($R^2={r2:.3f}$)")
ax[0].grid(ls=":", alpha=.5); ax[0].legend(loc="upper left", fontsize=8)

imp = sorted(R["task1_perm"].items(), key=lambda kv: kv[1][0])
imp = imp[-10:]  # ten largest
names = [k for k, _ in imp]; m = [v[0] for _, v in imp]; s = [v[1] for _, v in imp]
ax[1].barh(names, m, xerr=s, color="#4daf4a", edgecolor="k", linewidth=.4,
           error_kw=dict(lw=1, capsize=2))
ax[1].set_xlabel("Mean $R^2$ drop on held-out folds ($\\Delta R^2$; bars: s.d. over folds)")
ax[1].set_title("(b) Held-out permutation importance")
ax[1].grid(axis="x", ls=":", alpha=.5)
plt.tight_layout(); plt.savefig(OUT / "fig1.png", dpi=200); plt.close()

# ---------------- Fig. 2a: HRV gain by style
rows = R["descriptives"]["style_table"]
cols = {"pranayama": "#4daf4a", "restorative": "#377eb8", "yin": "#984ea3",
        "hatha": "#ff7f00", "vinyasa": "#e41a1c"}
fig, ax = plt.subplots(figsize=(6, 4.3))
x = np.arange(len(rows))
ax.bar(x, [r["hrv_mean"] for r in rows], yerr=[r["hrv_sd"] for r in rows],
       color=[cols[r["style"]] for r in rows], edgecolor="k", linewidth=.5, alpha=.85,
       error_kw=dict(lw=1.5, capsize=4))
for i, r in enumerate(rows):
    ax.text(i, 0.6, f"+{r['hrv_mean']:.1f}", ha="center", color="white", fontweight="bold")
ax.set_xticks(x); ax.set_xticklabels([r["style"].capitalize() for r in rows])
ax.set_ylabel("Acute HRV gain ($\\Delta$RMSSD, ms)")
ax.set_title("Task 2: simulated acute HRV gain by style (mean $\\pm$ s.d. over sessions)", fontsize=9)
ax.grid(axis="y", ls=":", alpha=.5); ax.set_axisbelow(True)
plt.tight_layout(); plt.savefig(OUT / "fig2a.png", dpi=200); plt.close()

# ---------------- Fig. 2b: confusion matrix (counts from pooled out-of-fold predictions)
cm = np.array(R["task3"]["random_forest"]["cm"])
labels = ["Mountain", "Tree", "Warrior II", "Downward Dog", "Child's Pose"]
fig, ax = plt.subplots(figsize=(4.4, 4.2))
ax.imshow(cm, cmap="Blues")
for i in range(5):
    for j in range(5):
        ax.text(j, i, cm[i, j], ha="center", va="center", fontweight="bold",
                color="white" if cm[i, j] > cm.max() / 2 else "black")
ax.set_xticks(range(5)); ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=8)
ax.set_yticks(range(5)); ax.set_yticklabels(labels, fontsize=8)
ax.set_xlabel("Predicted posture"); ax.set_ylabel("True posture")
ax.set_title("Task 3: pose classification", fontsize=10)
plt.tight_layout(); plt.savefig(OUT / "fig2b.png", dpi=200); plt.close()
print("figures written")
