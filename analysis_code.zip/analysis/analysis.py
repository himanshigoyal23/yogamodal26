"""Reproduces every number in the paper from the synthetic benchmark.

Usage:  python analysis.py DATA_DIR OUT_DIR [--repeats1 50] [--repeats2 5] [--skip-repeats]

DATA_DIR holds subjects.csv, sessions.csv, weekly_outcomes.csv, pose_keypoints.json
(produced by generate_dataset.py, seed 7).

Protocol
  * every split is by subject_id (no subject appears in both train and test);
  * outer loop: 5-fold subject-grouped CV;
  * hyper-parameters are chosen ONLY inside each outer training fold by a 3-fold
    subject-grouped inner CV (nested CV);
  * Task 1 is a week-4 forecast of the week-12 outcome.
"""
import json, sys, time, warnings
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LinearRegression, LogisticRegression, Ridge
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             mean_absolute_error, r2_score)
from sklearn.model_selection import GridSearchCV, GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
DATA, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
args = sys.argv[3:]
def opt(name, default):
    return int(args[args.index(name) + 1]) if name in args else default
REP1, REP2 = opt("--repeats1", 50), opt("--repeats2", 5)
SKIP_REP = "--skip-repeats" in args

# ------------------------------------------------------------------ grids
ALPHAS = [10.0 ** k for k in range(-3, 4)]
GRID_RIDGE = {"ridge__alpha": ALPHAS}
GRID_HGB = {"max_depth": [3, 5, None], "learning_rate": [0.05, 0.1], "max_iter": [100, 300]}
GRID_RF = {"n_estimators": [100, 300], "max_features": ["sqrt", "log2"]}
GRID_LR = {"logisticregression__C": [0.01, 0.1, 1.0, 10.0, 100.0]}

# ------------------------------------------------------------------- data
def load():
    sub = pd.read_csv(DATA / "subjects.csv")
    ses = pd.read_csv(DATA / "sessions.csv")
    wk = pd.read_csv(DATA / "weekly_outcomes.csv")
    kp = json.load(open(DATA / "pose_keypoints.json"))
    ses["hrv_gain"] = ses.post_hrv_rmssd - ses.pre_hrv_rmssd
    ses["d_stress_vas"] = ses.post_stress_vas - ses.pre_stress_vas
    ses["d_hr"] = ses.post_hr - ses.pre_hr
    ses = ses.sort_values("session_id").reset_index(drop=True)
    ses["prior_sessions"] = ses.groupby("subject_id").cumcount()
    return sub, ses, wk, kp

def outer_splits(groups, k, seed):
    """Random subject-level k-fold: returns list of (train_idx, test_idx)."""
    groups = np.asarray(groups)
    u = np.unique(groups)
    rng = np.random.default_rng(seed)
    rng.shuffle(u)
    fold_of = {g: i % k for i, g in enumerate(u)}
    f = np.array([fold_of[g] for g in groups])
    return [(np.where(f != i)[0], np.where(f == i)[0]) for i in range(k)]

def tune(est, grid, X, y, groups, seed, scoring):
    inner = GroupKFold(n_splits=3, shuffle=True, random_state=seed)
    gs = GridSearchCV(est, grid, cv=inner, scoring=scoring, n_jobs=2, refit=True)
    gs.fit(X, y, groups=groups)
    return gs.best_estimator_, gs.best_params_

# --------------------------------------------------------------- Task 1
def build_task1(sub, ses, wk):
    s = sub.set_index("subject_id")
    w = wk.pivot(index="subject_id", columns="week", values="stress")
    g = ses[ses.week <= 4].groupby("subject_id")
    f = pd.DataFrame(index=s.index)
    f["age"] = s.age
    f["sex_M"] = (s.sex == "M").astype(int)
    f["bmi"] = s.bmi
    for c in sorted(s.condition_group.unique()):
        f[f"condition_group_{c}"] = (s.condition_group == c).astype(int)
    f["baseline_stress"] = s.baseline_stress
    f["practice_freq_per_week"] = s.practice_freq_per_week
    f["n_early_sessions"] = g.size().reindex(f.index).fillna(0)
    f["stress_drop_w4"] = s.baseline_stress - w[4]
    f["hrv_gain_w1_4"] = g.hrv_gain.mean().reindex(f.index)
    f["pose_quality"] = g.pose_quality.mean().reindex(f.index)
    f["balance_score"] = g.balance_score.mean().reindex(f.index)
    y = (s.baseline_stress - w[12]).values
    return f, y, f.index.values

DEMOG = ["age", "sex_M", "bmi"] + [f"condition_group_{c}" for c in
        ["anxiety", "healthy", "hypertension", "low_back_pain", "poor_sleep"]]

def t1_models():
    return {
        "dummy_mean": (DummyRegressor(strategy="mean"), None, None),
        "early_change_only": (LinearRegression(), None, ["stress_drop_w4"]),
        "early_change+baseline": (LinearRegression(), None, ["stress_drop_w4", "baseline_stress"]),
        "ridge": (make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge()),
                  GRID_RIDGE, None),
        "hgb": (HistGradientBoostingRegressor(random_state=0, min_samples_leaf=10,
                                              l2_regularization=1.0), GRID_HGB, None),
    }

def run_cv_reg(X, y, groups, models, seed, k=5, perm=False, scoring="r2"):
    """Nested grouped CV for regression. Returns metrics, OOF predictions, chosen params."""
    folds = outer_splits(groups, k, seed)
    res = {}
    pimp = {c: [] for c in X.columns} if perm else None
    for name, (est, grid, cols) in models.items():
        Xm = X[cols] if cols else X
        oof = np.zeros(len(y)); fold_r2, fold_mae, params = [], [], []
        for tr, te in folds:
            if grid:
                m, p = tune(est, grid, Xm.iloc[tr], y[tr], np.asarray(groups)[tr], seed, scoring)
            else:
                from sklearn.base import clone
                m, p = clone(est).fit(Xm.iloc[tr], y[tr]), {}
            pr = m.predict(Xm.iloc[te]); oof[te] = pr
            fold_r2.append(r2_score(y[te], pr)); fold_mae.append(mean_absolute_error(y[te], pr))
            params.append({k_: (None if v is None else (v if not isinstance(v, (np.floating, np.integer)) else v.item()))
                           for k_, v in p.items()})
            if perm and name == "hgb":
                r = permutation_importance(m, Xm.iloc[te], y[te], n_repeats=30, random_state=seed,
                                           scoring="r2")
                for c, v in zip(Xm.columns, r.importances_mean):
                    pimp[c].append(v)
        res[name] = dict(r2_pooled=r2_score(y, oof), mae_pooled=mean_absolute_error(y, oof),
                         r2_fold_mean=float(np.mean(fold_r2)), r2_fold_sd=float(np.std(fold_r2)),
                         mae_fold_mean=float(np.mean(fold_mae)), params=params, oof=oof.tolist())
    return res, pimp

# --------------------------------------------------------------- Task 2
def build_task2(sub, ses, strict=False):
    d = ses.merge(sub, on="subject_id", how="left", suffixes=("", "_subj"))
    y = d.hrv_gain.values
    groups = d.subject_id.values
    cols = ["pre_hr", "pre_hrv_rmssd", "pre_resp_rpm", "pre_stress_vas", "duration_min",
            "prior_sessions"]
    if not strict:
        cols += ["pose_quality", "balance_score"]
    cols += ["age", "bmi", "experience_years", "practice_freq_per_week", "resting_hr",
             "baseline_hrv_rmssd", "baseline_stress", "baseline_sleep_hrs", "baseline_pain",
             "baseline_mood", "baseline_energy"]
    X = d[cols].copy()
    X["sex_M"] = (d.sex == "M").astype(int)
    for st in ["hatha", "vinyasa", "pranayama", "restorative", "yin"]:
        X[f"style_{st}"] = (d["style"] == st).astype(int)
        X[f"primary_{st}"] = (d.primary_style == st).astype(int)
    for c in ["anxiety", "healthy", "hypertension", "low_back_pain", "poor_sleep"]:
        X[f"condition_group_{c}"] = (d.condition_group == c).astype(int)
    return X, y, groups

def t2_models():
    style_cols = [f"style_{s}" for s in ["hatha", "vinyasa", "pranayama", "restorative", "yin"]]
    return {
        "dummy_mean": (DummyRegressor(strategy="mean"), None, None),
        "style_only": (LinearRegression(), None, style_cols),
        "ridge": (make_pipeline(StandardScaler(), Ridge()), GRID_RIDGE, None),
        "hgb": (HistGradientBoostingRegressor(random_state=0, l2_regularization=1.0),
                GRID_HGB, None),
    }

# --------------------------------------------------------------- Task 3
POSES = ["mountain", "tree", "warrior_ii", "downward_dog", "childs_pose"]
def build_task3(kp):
    recs = kp["records"]
    X = []
    for r in recs:
        c = np.array(r["landmarks"])[:, :2]
        hip = (c[23] + c[24]) / 2; sh = (c[11] + c[12]) / 2
        torso = np.linalg.norm(sh - hip) + 1e-6
        X.append(((c - hip) / torso).flatten())
    return (np.array(X), np.array([r["pose"] for r in recs]),
            np.array([r["subject_id"] for r in recs]))

def run_cv_clf(X, y, groups, seed=0, k=5):
    folds = outer_splits(groups, k, seed)
    models = {
        "dummy_most_frequent": (DummyClassifier(strategy="most_frequent"), None),
        "logreg": (make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)), GRID_LR),
        "random_forest": (RandomForestClassifier(random_state=0), GRID_RF),
    }
    res = {}
    for name, (est, grid) in models.items():
        from sklearn.base import clone
        pred = np.empty(len(y), dtype=object); params = []; accs = []; f1s = []
        for tr, te in folds:
            if grid:
                m, p = tune(est, grid, X[tr], y[tr], groups[tr], seed, "accuracy")
            else:
                m, p = clone(est).fit(X[tr], y[tr]), {}
            pred[te] = m.predict(X[te]); params.append(p)
            accs.append(accuracy_score(y[te], pred[te]))
            f1s.append(f1_score(y[te], pred[te], average="macro"))
        res[name] = dict(acc_pooled=accuracy_score(y, pred), f1_pooled=f1_score(y, pred, average="macro"),
                         acc_fold_mean=float(np.mean(accs)), acc_fold_sd=float(np.std(accs)),
                         cm=confusion_matrix(y, pred, labels=POSES).tolist(), params=params)
    return res

# ---------------------------------------------------------- descriptives
def descriptives(sub, ses, wk):
    out = {}
    per = ses.groupby("subject_id").size()
    out["n_subjects"] = len(sub); out["n_sessions"] = len(ses); out["n_weekly"] = len(wk)
    out["sessions_per_subject_min_max"] = [int(per.min()), int(per.max())]
    out["age_mean_sd"] = [sub.age.mean(), sub.age.std()]
    out["experience_mean_sd"] = [sub.experience_years.mean(), sub.experience_years.std()]
    out["condition_counts"] = sub.condition_group.value_counts().to_dict()
    st = ses.groupby("style").agg(
        n=("hrv_gain", "size"), hrv_mean=("hrv_gain", "mean"), hrv_sd=("hrv_gain", "std"),
        vas_mean=("d_stress_vas", "mean"), vas_sd=("d_stress_vas", "std"),
        hr_mean=("d_hr", "mean"), hr_sd=("d_hr", "std")).sort_values("hrv_mean", ascending=False)
    out["style_table"] = st.reset_index().to_dict(orient="records")
    w = wk.groupby("week")[["stress", "sleep_hrs", "pain", "mood"]].agg(["mean", "std"])
    for v in ["stress", "sleep_hrs", "pain"]:
        out[f"{v}_baseline_mean_sd"] = [sub[{"stress": "baseline_stress", "sleep_hrs": "baseline_sleep_hrs",
                                            "pain": "baseline_pain"}[v]].mean(),
                                        sub[{"stress": "baseline_stress", "sleep_hrs": "baseline_sleep_hrs",
                                             "pain": "baseline_pain"}[v]].std()]
        out[f"{v}_w4_mean_sd"] = [w[(v, "mean")][4], w[(v, "std")][4]]
        out[f"{v}_w12_mean_sd"] = [w[(v, "mean")][12], w[(v, "std")][12]]
    g = ses.groupby("week").hrv_gain.agg(["mean", "std"])
    out["hrv_gain_week1"] = [g.loc[1, "mean"], g.loc[1, "std"]]
    out["hrv_gain_week4"] = [g.loc[4, "mean"], g.loc[4, "std"]]
    out["hrv_gain_week12"] = [g.loc[12, "mean"], g.loc[12, "std"]]
    # pose quality vs HRV gain: pooled, subject means, within-subject, cluster bootstrap
    r_pool = np.corrcoef(ses.pose_quality, ses.hrv_gain)[0, 1]
    sm = ses.groupby("subject_id")[["pose_quality", "hrv_gain"]].mean()
    r_sub = np.corrcoef(sm.pose_quality, sm.hrv_gain)[0, 1]
    dm = ses[["pose_quality", "hrv_gain"]] - ses.groupby("subject_id")[["pose_quality", "hrv_gain"]].transform("mean")
    r_within = np.corrcoef(dm.pose_quality, dm.hrv_gain)[0, 1]
    rng = np.random.default_rng(0)
    by = {k: v[["pose_quality", "hrv_gain"]].values for k, v in ses.groupby("subject_id")}
    keys = list(by); boots = []
    for _ in range(1000):
        arr = np.concatenate([by[k] for k in rng.choice(keys, len(keys))])
        boots.append(np.corrcoef(arr[:, 0], arr[:, 1])[0, 1])
    out["pose_q_r_pooled"] = r_pool
    out["pose_q_r_pooled_cluster_boot_ci95"] = np.percentile(boots, [2.5, 97.5]).tolist()
    out["pose_q_r_subject_means"] = r_sub
    out["pose_q_r_within_subject"] = r_within
    hi, lo = ses[ses.balance_score > .85], ses[ses.balance_score < .60]
    out["balance_gt85"] = [len(hi), hi.hrv_gain.mean(), hi.hrv_gain.std()]
    out["balance_lt60"] = [len(lo), lo.hrv_gain.mean(), lo.hrv_gain.std()]
    return out

# ------------------------------------------------------------------ main
if __name__ == "__main__":
    t0 = time.time()
    sub, ses, wk, kp = load()
    R = {"descriptives": descriptives(sub, ses, wk)}
    print("descriptives done", round(time.time() - t0), "s", flush=True)

    # ---- Task 1
    X1, y1, g1 = build_task1(sub, ses, wk)
    R["task1_target_mean_sd"] = [float(y1.mean()), float(y1.std())]
    res1, pimp = run_cv_reg(X1, y1, g1, t1_models(), seed=0, perm=True)
    R["task1"] = res1
    R["task1_perm"] = {c: [float(np.mean(v)), float(np.std(v))] for c, v in pimp.items()}
    # ablation (HGB, same nested protocol)
    abl = {}
    variants = {
        "A_demographics+condition": DEMOG,
        "B_A+baseline_stress": DEMOG + ["baseline_stress"],
        "C_full_week4_model": list(X1.columns),
        "D_C_without_stress_drop_w4": [c for c in X1.columns if c != "stress_drop_w4"],
        "E_baseline+early_engagement_only": DEMOG + ["baseline_stress", "practice_freq_per_week", "n_early_sessions"],
    }
    for k_, cols in variants.items():
        m = {"hgb": (HistGradientBoostingRegressor(random_state=0, min_samples_leaf=10, l2_regularization=1.0),
                     GRID_HGB, None)}
        r, _ = run_cv_reg(X1[cols], y1, g1, m, seed=0)
        abl[k_] = {kk: r["hgb"][kk] for kk in ["r2_pooled", "mae_pooled", "r2_fold_mean", "r2_fold_sd"]}
        print("ablation", k_, round(abl[k_]["r2_pooled"], 3), flush=True)
    R["task1_ablation"] = abl
    R["task1_subject_ids"] = list(g1)
    R["task1_y"] = y1.tolist()
    print("task1 done", round(time.time() - t0), "s", flush=True)
    json.dump(R, open(OUT / "results.json", "w"), indent=1, default=float)

    # ---- Task 2
    X2, y2, g2 = build_task2(sub, ses)
    res2, _ = run_cv_reg(X2, y2, g2, t2_models(), seed=0)
    R["task2"] = {k_: {kk: v for kk, v in d.items() if kk != "oof"} for k_, d in res2.items()}
    X2s, y2s, g2s = build_task2(sub, ses, strict=True)
    m_h = {"hgb": t2_models()["hgb"]}
    r2s, _ = run_cv_reg(X2s, y2s, g2s, m_h, seed=0)
    R["task2_strict_pre_session"] = {kk: v for kk, v in r2s["hgb"].items() if kk != "oof"}
    print("task2 done", round(time.time() - t0), "s", flush=True)
    json.dump(R, open(OUT / "results.json", "w"), indent=1, default=float)

    # ---- Task 3
    X3, y3, g3 = build_task3(kp)
    R["task3"] = run_cv_clf(X3, y3, g3, seed=0)
    R["task3_class_counts"] = pd.Series(y3).value_counts().to_dict()
    print("task3 done", round(time.time() - t0), "s", flush=True)
    json.dump(R, open(OUT / "results.json", "w"), indent=1, default=float)

    # ---- repeated random subject partitions (full nested CV each time)
    if not SKIP_REP:
        rep1 = {k_: [] for k_ in ["early_change_only", "early_change+baseline", "ridge", "hgb"]}
        mods = {k_: v for k_, v in t1_models().items() if k_ in rep1}
        for s in range(1, REP1 + 1):
            r, _ = run_cv_reg(X1, y1, g1, mods, seed=s)
            for k_ in rep1:
                rep1[k_].append(r[k_]["r2_pooled"])
        R["task1_repeats"] = {k_: [float(np.mean(v)), float(np.std(v)), len(v)] for k_, v in rep1.items()}
        print("task1 repeats done", round(time.time() - t0), "s", flush=True)
        rep2 = {"hgb_r2": [], "hgb_mae": []}
        for s in range(1, REP2 + 1):
            r, _ = run_cv_reg(X2, y2, g2, {"hgb": t2_models()["hgb"]}, seed=s)
            rep2["hgb_r2"].append(r["hgb"]["r2_pooled"]); rep2["hgb_mae"].append(r["hgb"]["mae_pooled"])
        R["task2_repeats"] = {k_: [float(np.mean(v)), float(np.std(v)), len(v)] for k_, v in rep2.items()}
        json.dump(R, open(OUT / "results.json", "w"), indent=1, default=float)

    np.save(OUT / "task1_oof_hgb.npy", np.array(res1["hgb"]["oof"]))
    np.save(OUT / "task2_oof_hgb.npy", np.array(res2["hgb"]["oof"]))
    print("ALL DONE", round(time.time() - t0), "s")
