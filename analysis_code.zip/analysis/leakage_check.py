"""Shows how much random (row-level) K-fold inflates scores versus subject-grouped CV.
Same models, grids and nested tuning as analysis.py; only the splitting changes.
Usage: python leakage_check.py DATA_DIR OUT_DIR"""
import sys, json
from pathlib import Path
import numpy as np
data, out = sys.argv[1], sys.argv[2]
sys.argv = ["analysis.py", data, out, "--skip-repeats"]
sys.path.insert(0, str(Path(__file__).parent))
import analysis as A
from sklearn.model_selection import GridSearchCV, KFold

def random_splits(groups, k, seed):
    idx = np.arange(len(groups))
    return [(tr, te) for tr, te in KFold(k, shuffle=True, random_state=seed).split(idx)]
def random_tune(est, grid, X, y, groups, seed, scoring):
    gs = GridSearchCV(est, grid, cv=KFold(3, shuffle=True, random_state=seed), scoring=scoring, n_jobs=2)
    gs.fit(X, y); return gs.best_estimator_, gs.best_params_

sub, ses, wk, kp = A.load()
res = {}
X2, y2, g2 = A.build_task2(sub, ses)
X3, y3, g3 = A.build_task3(kp)
m2 = {"hgb": A.t2_models()["hgb"]}
for mode in ["grouped", "random"]:
    if mode == "random":
        A.outer_splits, A.tune = random_splits, random_tune
    r2, _ = A.run_cv_reg(X2, y2, g2, m2, seed=0)
    res[f"task2_{mode}"] = dict(r2=r2["hgb"]["r2_pooled"], mae=r2["hgb"]["mae_pooled"])
    c = A.run_cv_clf(X3, y3, g3, seed=0)
    res[f"task3_{mode}_rf"] = dict(acc=c["random_forest"]["acc_pooled"])
    print(mode, res[f"task2_{mode}"], res[f"task3_{mode}_rf"], flush=True)
json.dump(res, open(Path(out) / "leakage_check.json", "w"), indent=1)
